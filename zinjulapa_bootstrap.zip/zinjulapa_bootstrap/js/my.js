function showMsg() {
	console.log("Viss strādā");
}